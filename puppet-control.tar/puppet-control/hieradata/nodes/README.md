node specific settings
